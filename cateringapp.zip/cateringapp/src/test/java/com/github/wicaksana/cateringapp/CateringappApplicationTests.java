package com.github.wicaksana.cateringapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CateringappApplicationTests {

	@Test
	void contextLoads() {
	}

}
